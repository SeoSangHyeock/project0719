
public class test01 {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		System.out.println("I'm a new Java programmer");

	}

}
